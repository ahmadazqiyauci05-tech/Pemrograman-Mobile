package com.example.latiahnnavigasi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
